package appointment_system.ui;

import appointment_system.domain.AppointmentSlot;
import appointment_system.repository.AppointmentRepository;
import appointment_system.repository.UserRepository;
import appointment_system.service.AppointmentService;
import appointment_system.service.AuthenticationService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Modern GUI for the Appointment System.
 * @author Team 3
 */
public class MainGUI extends JFrame {

    private final AppointmentService appointmentService;
    private final AuthenticationService authService;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    
    // الألوان العصرية الفخمة
    private final Color COLOR_PRIMARY = new Color(33, 47, 61); // Midnight Blue
    private final Color COLOR_ACCENT = new Color(52, 152, 219);  // Bright Blue
    private final Color COLOR_SUCCESS = new Color(46, 204, 113); // Emerald Green
    private final Color COLOR_BG = new Color(242, 244, 244);     // Light Gray

    public MainGUI(AuthenticationService authService, AppointmentService appointmentService) {
        this.authService = authService;
        this.appointmentService = appointmentService;

        setTitle("Appointment Management System");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        // إضافة الشاشات بترتيب منطقي
        cardPanel.add(createStartScreen(), "START");
        cardPanel.add(createAdminLoginView(), "ADMIN_LOGIN");
        cardPanel.add(createAdminDashboard(), "ADMIN_DASHBOARD");
        cardPanel.add(createUserBookingView(), "USER_VIEW");

        add(cardPanel);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // --- 1. شاشة البداية الاحترافية (Centralized) ---
    private JPanel createStartScreen() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        JPanel box = new JPanel();
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.setOpaque(false);

        JLabel title = new JLabel("Appointment Management Portal");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(COLOR_PRIMARY);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnUser = createStyledButton("Customer: Visual Booking", COLOR_ACCENT);
        JButton btnAdmin = createStyledButton("Staff: Administration Access", COLOR_PRIMARY);

        btnUser.addActionListener(e -> cardLayout.show(cardPanel, "USER_VIEW"));
        btnAdmin.addActionListener(e -> cardLayout.show(cardPanel, "ADMIN_LOGIN"));

        box.add(title); box.add(Box.createRigidArea(new Dimension(0, 50)));
        box.add(btnUser); box.add(Box.createRigidArea(new Dimension(0, 15)));
        box.add(btnAdmin);
        p.add(box);
        return p;
    }

    // --- 2. واجهة المستخدم (Modern Timeline Grid) ---
    private JPanel createUserBookingView() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(COLOR_BG);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(15, 30, 15, 30));
        JLabel title = new JLabel("Available Time Slots - Book Now");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        JButton back = new JButton("Home");
        back.addActionListener(e -> cardLayout.show(cardPanel, "START"));
        header.add(title, BorderLayout.WEST); header.add(back, BorderLayout.EAST);

        // Grid للمواعيد
        JPanel grid = new JPanel(new GridLayout(0, 3, 20, 20));
        grid.setBackground(COLOR_BG);
        grid.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        // عينات تجريبية للمظهر
        for(int i=0; i<6; i++) {
            grid.add(createSlotCard(i+9));
        }

        main.add(header, BorderLayout.NORTH);
        main.add(new JScrollPane(grid), BorderLayout.CENTER);
        return main;
    }

    private JPanel createSlotCard(int hour) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        
        JLabel timeLbl = new JLabel(hour + ":00 AM", SwingConstants.CENTER);
        timeLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        timeLbl.setForeground(COLOR_PRIMARY);
        card.add(timeLbl, BorderLayout.NORTH);
        
        JButton book = new JButton("Book (120 min max)");
        book.setBackground(COLOR_ACCENT); book.setForeground(Color.WHITE);
        book.addActionListener(e -> JOptionPane.showMessageDialog(this, "Booked!"));
        card.add(book, BorderLayout.SOUTH);
        
        return card;
    }

    // --- 3. تسجيل دخول المسؤول (Modern Login Card) ---
    private JPanel createAdminLoginView() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(COLOR_BG);
        
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            new EmptyBorder(40, 40, 40, 40)
        ));
        card.setBackground(Color.WHITE);

        JTextField u = new JTextField(15); u.setBorder(BorderFactory.createTitledBorder("Username"));
        JPasswordField ps = new JPasswordField(15); ps.setBorder(BorderFactory.createTitledBorder("Password"));
        JButton loginBtn = createStyledButton("Login Now (US1.1)", COLOR_PRIMARY);

        loginBtn.addActionListener(e -> {
            // الآن الزر سيعمل وينقلك للداشبورد فوراً
            if (authService.login(u.getText(), new String(ps.getPassword()))) {
                cardLayout.show(cardPanel, "ADMIN_DASHBOARD");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials! (admin/1234)", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        card.add(new JLabel("ADMIN AUTHENTICATION")); card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(u); card.add(ps); card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(loginBtn);
        p.add(card);
        return p;
    }

    // --- 4. لوحة تحكم المسؤول (Management Dashboard) ---
    private JPanel createAdminDashboard() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(COLOR_BG);
        
        // Header
        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(COLOR_PRIMARY);
        head.setBorder(new EmptyBorder(15, 25, 15, 25));
        
        JLabel title = new JLabel("Administration Dashboard");
        title.setForeground(Color.WHITE); title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        
        JButton logout = new JButton("Logout (US1.2)");
        logout.addActionListener(e -> { authService.logout(); cardLayout.show(cardPanel, "START"); });
        
        head.add(title, BorderLayout.WEST); head.add(logout, BorderLayout.EAST);

        // جدول الحجوزات
        String[] cols = {"User", "Status", "Duration"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        
        main.add(head, BorderLayout.NORTH);
        main.add(new JScrollPane(table), BorderLayout.CENTER);
        return main;
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg); b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setFocusPainted(false); b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(250, 45));
        return b;
    }

    public static void main(String[] args) {
        // تهيئة الـ Layers
        AppointmentRepository repo = new AppointmentRepository();
        UserRepository userRepo = new UserRepository();
        AppointmentService service = new AppointmentService(repo);
        AuthenticationService auth = new AuthenticationService(userRepo);
        
        // تشغيل التطبيق بمظهر النظام
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new MainGUI(auth, service));
    }
}